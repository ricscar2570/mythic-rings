#!/usr/bin/env python3
"""Fail early when a handoff contains environment-specific or generated files."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors=[]

lock = ROOT / 'package-lock.json'
if lock.exists():
    text=lock.read_text(encoding='utf-8', errors='ignore')
    forbidden_hosts = [
        'packages.applied-caas-gateway',
        'internal.api.openai.org/artifactory',
        'localhost',
        '127.0.0.1',
    ]
    for host in forbidden_hosts:
        if host in text:
            errors.append(f'package-lock.json contiene registry non portabile: {host}')

for p in ROOT.rglob('*'):
    if not p.is_file():
        continue
    rel=p.relative_to(ROOT)
    if '__pycache__' in rel.parts or p.suffix == '.pyc':
        errors.append(f'cache Python presente nella repository: {rel}')

req=(ROOT/'requirements.txt').read_text(encoding='utf-8', errors='ignore') if (ROOT/'requirements.txt').exists() else ''
for package in ('PyMuPDF','PyYAML','python-docx'):
    if not re.search(rf'(?mi)^\s*{re.escape(package)}\b', req):
        errors.append(f'dipendenza Python di release non dichiarata: {package}')

if errors:
    for e in errors:
        print('ERRORE:', e)
    raise SystemExit(1)
print('Controllo portabilità repository superato.')
