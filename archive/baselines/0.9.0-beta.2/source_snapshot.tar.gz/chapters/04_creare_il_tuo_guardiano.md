---
title: "Creare il Tuo Guardiano"
chapter: 4
part: "Parte I: Il Mondo di Mythic Rings"
section: "Il Mondo di Mythic Rings"
epigraph: "Non sei chi eri prima dell'Anello. Non sei ancora chi diventerai."
tags: []
status: beta
version: 0.9.0-beta.2
---

## Creare il Tuo Guardiano

Sei pronto a diventare Guardiano? Non servono ore di preparazione. Non
servono tabelle infinite. Servono una manciata di scelte significative e
la volontà di dare vita a un personaggio che sia più di una scheda -
che sia una persona con una storia, dei legami e una ragione per
rischiare la vita ogni notte nelle strade di Milano.

Questo capitolo ti guida attraverso nove passi. Ogni passo è una scelta.
Ogni scelta racconta qualcosa del tuo personaggio. Alla fine, avrai un
Guardiano pronto a entrare in gioco - completo non solo di numeri, ma
di una storia che aspetta solo di essere raccontata.

## PASSO 1: CONCEPT

Prima dei numeri, prima della Casata, prima dei poteri - c'è una
persona. Il tuo Guardiano era qualcuno prima di ottenere l'Anello, e
quel qualcuno è la fondazione su cui costruirai tutto il resto. Il
concept è la risposta a quattro domande:

**Chi eri PRIMA di diventare Guardiano?** Uno studente di architettura
che passava le notti a disegnare? Un poliziotto che aveva visto troppo?
Un'artista di strada che dipingeva murales sui Navigli? Un disoccupato
che viveva in un monolocale a Quarto Oggiaro e non aveva più nulla da
perdere? La vita precedente del tuo personaggio definisce le sue
competenze mondane, le sue connessioni sociali e il tono del suo arco
narrativo.

**Come hai ottenuto l'Anello?** L'Anello sceglie - non viene trovato.
Ma le circostanze della Scelta variano enormemente. Forse è apparso al
tuo dito durante un momento di disperazione assoluta - un incidente,
un'aggressione, un incendio. Forse l'hai ereditato da un Guardiano
morente che ti ha passato il testimone con il suo ultimo respiro. Forse
ti sei svegliato una mattina e l'Anello era lì, e nessuno è mai venuto a
spiegarti perché.

**Perché hai accettato?** Accettare l'Anello non è automatico. Puoi
rifiutare. La maggior parte delle persone lo fa - l'Anello trova
qualcun altro. Ma tu hai accettato. Perché? Vendetta per qualcuno che
hai perso? Senso del dovere verso una città che ami? Curiosità per un
mondo che intuivi esistesse? O semplicemente perché non avevi scelta -
il mostro era già lì, e l'Anello era l'unica cosa che ti separava dalla
morte?

**Cosa ti definisce?** Una parola. Solo una. Coraggioso. Cinico.
Curioso. Spezzato. Leale. Vendicativo. Affamato. Gentile. Questa parola
è la bussola del tuo personaggio - quando non sai cosa farebbe il tuo
PG in una situazione, torna a questa parola.

:::box[Consiglio: Il Concept Viene Prima della Casata]{type=info}
Non scegliere la Casata e poi costruire il personaggio attorno ad essa. Fai il contrario: crea una persona vera e poi lascia che la Casata la trovi. Un ex-chirurgo potrebbe sembrare un Ife naturale, ma se la sua motivazione è la vendetta per un paziente ucciso da un demone, forse l'Anello Avalon risuona con la sua rabbia giusta.
:::

:::box[Consiglio: Il Concept Viene Prima della Casata (segue)]{type=info}
Un'artista di strada potrebbe sembrare una Umbra, ma se la sua arte è un modo per processare il lutto, forse Mictlan la chiama. I personaggi più interessanti sono quelli in cui il concept e la Casata creano una tensione produttiva.
:::

## PASSO 2: SCEGLI LA CASATA

Leggi le descrizioni delle quattro Casate nel Capitolo 3. Poi chiediti:

**Filosofia:** Ti identifichi con i valori della Casata? Un Avalon crede
nella giustizia. Un Umbra crede nella necessità. Un Ife crede
nell'equilibrio. Un Mictlan crede nell'accettazione. Quale di queste
risuona con il tuo concept?

**Poteri:** Che tipo di magia vuoi usare? Luce e guarigione (Avalon),
ombre e inganno (Umbra), natura e metamorfosi (Ife), o morte e spiriti
(Mictlan)?

**Costo:** Ogni potere ha un prezzo. Stress per Avalon e Ife
(esaurimento mentale). Corruzione per Umbra (erosione dell'anima, scala
0--8). Punti Ferita per Mictlan (la tua stessa vita). Quale prezzo sei
disposto a pagare?

**Mosse Esclusive:** Ogni Casata ha due mosse uniche che definiscono il
suo stile. Voce dell'Autorità e Luce della Verità per Avalon. Leggere le
Ombre e Colpo dall'Ombra per Umbra. Sentire la Vita e Simbiosi per Ife.
Interrogare i Morti e Presagio per Mictlan. Quale stile ti attrae?

:::box[Nota: Mix di Casate nel Gruppo]{type=info}
Ogni gruppo dovrebbe avere un mix di Casate. Non è obbligatorio - quattro Avalon possono funzionare se il Custode adatta la campagna - ma la diversità è forza. Un gruppo con quattro Casate diverse copre ogni situazione: l'Avalon ispira e protegge, l'Umbra infiltra e scopre, l'Ife cura e connette, il Mictlan interroga e accetta. E le tensioni tra filosofie diverse generano il drama più autentico.
:::

:::box[Nota: Mix di Casate nel Gruppo (segue)]{type=info}
Ecco perché il Passo 2 si fa insieme, alla Session Zero.
:::

## PASSO 3: NOME E DETTAGLI

Dai al tuo personaggio un'identità concreta. Ogni dettaglio è
un'opportunità narrativa:

**Nome completo.** Italiano, straniero, soprannome operativo - Milano
è una città cosmopolita e i Custodi vengono da tutto il mondo. Il nome
dice molto: «Marco Ferretti» è un nome diverso da «Spettro» o da «Nonna
Rosa».

**Età.** I Guardiani possono avere qualsiasi età tra i 18 e i 60+ anni.
L'Anello non discrimina. Un Guardiano di 22 anni ha una storia diversa
da uno di 55: diversa esperienza, diversi Legami, diverso rapporto con
la mortalità.

**Aspetto.** Scegli 3--5 tratti distintivi. Non «altezza e peso» -
tratti che un osservatore noterebbe: una cicatrice sul collo, capelli
grigi prematuri, un tatuaggio tribale sull'avambraccio, occhiali spessi,
l'abitudine di portare sempre una giacca di pelle nera. Questi tratti
sono ganci narrativi per il Custode.

**Vita normale.** Che lavoro fai? Che scuola frequenti? I Guardiani
devono mantenere una copertura - la doppia vita è parte del gioco. Un
detective privato ha una copertura perfetta. Un chirurgo che scompare
durante i turni di notte, meno.

**Quartiere.** Dove vivi a Milano? Il quartiere non è solo un indirizzo:
è atmosfera, risorse, pericoli. Un Guardiano che vive ai Navigli ha
accesso alla vita notturna e al commercio occulto. Uno che vive in zona
Centrale è vicino a un potenziale portale dimensionale. Consulta il
Capitolo dei Quartieri per dettagli.

## PASSO 4: CARATTERISTICHE

Il tuo Guardiano ha **5 caratteristiche** che definiscono le sue
capacità fisiche, mentali e soprannaturali. Distribuisci tra queste i
seguenti valori: **+2, +1, +1, 0, -1**. Ogni caratteristica va da -1
(debole) a +2 (eccellente) alla creazione, e può crescere fino a +3 con
l'esperienza.


| STAT | Nome | Cosa Rappresenta |
|---| ---|---|
| FOR | Forza | Potenza fisica, resistenza corporea, salute. Determina i PF e la capacità di colpire, sfondare, sopportare. |
| CUO | Cuore | Coraggio, istinto, riflessi, agilità. Usato per agire sotto pressione, difendere, reagire al pericolo. |
| MEN | Mente | Intelligenza, percezione, memoria, analisi. Usato per investigare, leggere situazioni, ricordare informazioni cruciali. |
| CAR | Carisma | Fascino, leadership, presenza, persuasione. Usato per convincere, ispirare, manipolare, comandare. Stat primaria Avalon. |
| FAT | Fato | Fortuna, destino, connessione magica con l'Anello. Usato per canalizzare i poteri della Casata. Stat primaria Umbra, Ife, Mictlan. |

## Distribuzioni Consigliate per Casata

Queste distribuzioni sono consigli, non obblighi. Ma se è la tua prima
partita, seguirle ti garantisce un personaggio meccanicamente solido:


| Casata | FOR | CUO | MEN | CAR | FAT | Razionale |
|---| ---|---| ---|---| ---|---|
| Avalon | +1 | +1 | 0 | +2 | -1 | CAR alimenta poteri e Mosse Esclusive. FOR/CUO per sopravvivere in prima linea. |
| Umbra | -1 | +1 | +1 | 0 | +2 | FAT per poteri e Leggere le Ombre. CUO per Colpo dall'Ombra e schivare. MEN per investigare. |
| Ife | 0 | +1 | -1 | +1 | +2 | FAT per poteri e Sentire la Vita. CAR per mediare e relazioni. CUO per situazioni d'emergenza. |
| Mictlan | +1 | +1 | 0 | -1 | +2 | FAT per poteri e Interrogare i Morti. FOR importante: più PF = più carburante per i poteri. |

:::box[Perché FOR è Importante per Mictlan]{type=warn}
I Mictlan pagano i poteri in Punti Ferita. FOR determina i PF
iniziali. Un Mictlan con FOR +1 ha 29 PF (28 + 1), contro i 27 di uno
con FOR -1 (28 - 1). Quei 2 PF di differenza valgono un potere L2 in più
prima di entrare in zona critica. Per un Mictlan, la Forza non è solo
muscoli - è carburante.
:::

:::box[FAT è la Stat di Lancio - ed è una Scelta, non uno Sbilanciamento]{type=info}
FAT canalizza i poteri di Umbra, Ife e Mictlan (Avalon usa CAR). Sembra una "stat divina", ma non lo è: FAT non difende, non schiva, non colpisce in mischia e non investiga. Difendere e Attaccare usano FOR/CUO, Sfidare Pericolo usa CUO/MEN, l'indagine usa MEN. Un Guardiano tutto-FAT ha poteri eccellenti ma è fragile e goffo in combattimento - un glass cannon:
:::

:::box[FAT è la Stat di Lancio - ed è una Scelta, non uno Sbilanciamento (segue)]{type=info}
scaricare FOR, CUO o MEN ha sempre un prezzo concreto.

Il caso a parte è Mictlan, che trae vantaggio sia da FAT sia da FOR. La formula 28 + FOR garantisce una riserva di PF elevata senza rendere obbligatoria una Caratteristica fisica massima: un Mictlan può privilegiare la magia e restare comunque resistente.
:::

## PASSO 5: PUNTI FERITA E RISORSE

## Punti Ferita

**PF Iniziali = 20 + (FOR × 2)** per Avalon, Umbra e Ife. Esempio: FOR
+1 → PF = 20 + 2 = 22.

**PF Iniziali Mictlan = 28 + (FOR × 1)**. A parità di FOR, i Mictlan hanno una riserva iniziale superiore alle altre Casate: il vantaggio va da 9 PF con FOR −1 a 5 PF con FOR +3. Il moltiplicatore di FOR è dimezzato, quindi la Casata resta resistente anche senza massimizzare la caratteristica fisica.
Questa resistenza riflette la loro connessione con il confine tra vita e
morte: i loro poteri consumano la loro stessa vita.
Esempio: Mictlan con FOR +1 → PF = 28 + 1 = 29.


| FOR | PF Standard | PF Mictlan | Nota |
|---| ---|---| ---|
| -1 | 18 | 27 | Fragile. Evita la prima linea. |
| 0 | 20 | 28 | Nella media. Sopravvivi con cautela. |
| +1 | 22 | 29 | Solido. Puoi permetterti qualche rischio. |
| +2 | 24 | 30 | Robusto. Puoi incassare colpi e alimentare poteri. |

## Risorse iniziali

| Risorsa | Valore iniziale | Regola essenziale |
|---|---:|---|
| Stress | 0, massimo 10 | A 8–9 i poteri che costano Stress costano 1 in più; a 10 sei in Burnout |
| Corruzione | 0, massimo 8 | Solo Umbra; a 8 il Guardiano si trasforma e diventa PNG salvo un effetto esplicito |
| Punti Fato | 2, massimo 2 | Si ripristinano a inizio sessione; 1 punto ritira un solo d6 |
| Armatura | 0 | L'equipaggiamento può fornire fino a 3; il totale ordinario non supera 4 |

## PASSO 6: POTERI INIZIALI

Scegli **3 poteri di Livello 1** dalla lista della tua Casata. Il Livello 1 rappresenta il primo controllo consapevole dell'Anello: capacità affidabili, abbastanza versatili da definire lo stile del Guardiano senza risolvere da sole ogni scena.

Per un primo personaggio, scegli preferibilmente:

- **un potere offensivo o di controllo**, capace di creare un'apertura o infliggere danno;
- **un potere difensivo o di mobilità**, utile quando la posizione diventa pericolosa;
- **un potere informativo, sociale o caratterizzante**, che mostri come il tuo Guardiano affronta i problemi.

Questa distribuzione è un consiglio, non un requisito. Due Guardiani della stessa Casata possono scegliere combinazioni completamente diverse.

I Mictlan ricevono gratuitamente anche il potere passivo L1 **Sangue Tenace**, oltre ai tre poteri scelti. I poteri Umbra L1 non costano Corruzione, salvo indicazione esplicita.

Prima di terminare, annota per ogni potere:

- trigger e Caratteristica;
- costo;
- portata e durata;
- effetto di 10+, 7–9 e 6−, quando richiede un tiro;
- eventuali limiti per scena o sessione.

## PASSO 7: EQUIPAGGIAMENTO BASE

Tutti i Guardiani iniziano con lo stesso kit base, fornito
dall'Organizzazione dei Custodi al momento della Scelta:

**Anello di Custodia** - al dito, indistruttibile, fonte dei tuoi
poteri e del tuo legame con la Casata. Non può essere rimosso se non
volontariamente (e rimuoverlo significa rinunciare a essere Guardiano).

**Smartphone criptato** - con l'app dei Custodi installata:
comunicazione sicura, segnali d'allarme, mappa delle Linee Ley, database
creature. Sembra un normale telefono.

**Auricolare** - per la comunicazione in tempo reale con il gruppo
durante le operazioni.

**500€ in contanti** - fondo operativo. Non chiedere la ricevuta.

**1 arma da mischia** - a scelta: coltello a serramanico, bastone
telescopico, mazza, tirapugni, o qualsiasi arma che il tuo personaggio
saprebbe usare. L'Organizzazione non giudica.

**Abbigliamento civile + outfit operativo** - vestiti normali per la
vita di giorno, vestiti scuri e funzionali per le operazioni notturne.

**Opzionale:** scegli anche una **pistola** se è coerente con storia, addestramento e copertura del personaggio. Non richiede un valore minimo di FOR. È un'arma a distanza che infligge **2d6 danni fisici**, richiede entrambe le mani per essere usata con precisione e può attirare immediatamente attenzione civile e forze dell'ordine. Molte creature possiedono resistenze specifiche, ma nessuna ignora un'arma soltanto perché non è magica, salvo immunità dichiarata.

## PASSO 8: LEGAMI

Scegli **2 PNG** con cui hai un Legame di livello 1. I Legami sono le
relazioni che ancorano il tuo Guardiano alla vita normale - le persone
per cui combatti, le ragioni per cui torni a casa vivo. Sono anche una
risorsa meccanica: i Legami danno bonus concreti in gioco e sbloccano
mosse speciali man mano che crescono.

## Tipi di Legame

Ogni Legame ha un Tipo e un Livello da 0 a 3. Il Livello determina il bonus; il Tipo stabilisce quando la relazione è pertinente.

| Livello | Effetto |
|---:|---|
| 0 | Rapporto spezzato o non più significativo; nessun bonus |
| 1 | +1 quando la persona e il Tipo sono direttamente coinvolti |
| 2 | Il bonus diventa +2 |
| 3 | Il bonus resta +2 e si sblocca la capacità speciale |

| Tipo | Trigger | Capacità speciale di Livello 3 |
|---|---|---|
| Protettore | Rischi per difendere la persona legata | **Interposizione:** una volta per sessione prendi al suo posto una conseguenza fisica appena annunciata |
| Confidente | Ti apri, ti ricomponi o resisti grazie al suo sostegno | **Catarsi:** una volta per sessione, dopo una scena sincera, riduci di 1d4 lo Stress |
| Rivale | Affronti un rischio per superarlo o dimostrargli qualcosa | **Sprone:** una volta per sessione ritira un dado di una Mossa pertinente senza spendere Fato |
| Mentore | Applichi direttamente un insegnamento o una conoscenza ricevuta | **Intuizione:** una volta per sessione poni una domanda aggiuntiva dopo Leggere la Situazione o Investigare |
| Amato | Agisci per proteggerlo, raggiungerlo o mantenere una promessa | **Radicamento:** una volta per sessione ignora 1 Stress appena ottenuto o resta cosciente fino alla fine della scena nonostante una Condizione |

Un solo Legame può modificare lo stesso tiro. Il coinvolgimento deve essere diretto e significativo: pensare genericamente a una persona non concede il bonus. I Legami non modificano Ultimo Respiro.

I Legami possono unire familiari, amici, colleghi, altri Custodi, contatti o entità capaci di una relazione autentica. Per ciascuno scrivi nome, rapporto, Tipo, motivo dell'importanza e una domanda irrisolta.

### Designa la tua Ancora dell'Anello

Scegli **uno dei tuoi Legami L1** e segnalo come **Ancora dell'Anello**. È la relazione che ricorda al Guardiano chi è quando l'Anello cerca di trasformare una necessità in un assoluto. L'Ancora non concede un bonus aggiuntivo ai tiri.

Una volta per sessione, se l'Ancora è direttamente presente o in contatto significativo nella scena e il Custode ti offre **Anima** come prezzo di Risonanza, puoi chiedere di sostituirlo con un prezzo **Legame** che coinvolga l'Ancora. Il Custode dichiara il nuovo prezzo prima che tu decida. Se l'altro prezzo era già Legame, i due prezzi possono eccezionalmente appartenere alla stessa categoria ma devono descrivere conseguenze diverse. Se il Legame-Ancora viene spezzato o scende a L0, dovrai stabilirne un'altra attraverso una scena significativa; non puoi sostituirla nel mezzo di una risoluzione.

:::box[Legami tra Guardiani]{type=info}
Durante la Sessione Zero, ogni giocatore crea almeno un Legame verso un altro Guardiano. Non deve essere positivo: un Rivale, un Mentore riluttante o un Protettore non ricambiato producono tensione utile, purché tutti desiderino giocarla.
:::

:::box[Spezzare un Legame]{type=warn}
Quando morte, tradimento o separazione definitiva spezzano il rapporto, il Livello scende a 0 e il Guardiano subisce 2 Stress. Il Legame può essere ricostruito soltanto attraverso scene e decisioni che trasformino davvero la relazione.
:::

## PASSO 9: TOCCHI FINALI

Gli ultimi quattro elementi non hanno effetto meccanico diretto, ma sono
la bussola del tuo roleplay - il Custode li userà per creare scene su
misura per il tuo personaggio:

**Citazione.** Una frase che cattura l'essenza del tuo PG. Non deve
essere profonda - deve essere vera. «Ho giurato di proteggere. Non
importa da cosa.» «Le ombre non sono il nemico. Il nemico è la luce che
ti acceca.» «Ogni vita conta. Anche la mia, a volte.» «I morti non
mentono. I vivi, sempre.»

**Paura.** Cosa teme di più il tuo personaggio? Non i mostri - quelli
li combatte. La paura vera è personale: fallire chi dipende da te,
perdere il controllo, diventare ciò che combatti, restare solo, scoprire
che nulla di ciò che fai conta.

**Desiderio.** Cosa vuole ottenere? Redenzione, vendetta, risposte,
pace, amore, potere? Il desiderio è il motore narrativo del personaggio
- la cosa che lo spinge ad alzarsi quando tutto gli dice di restare a
terra.

**Segreto.** Cosa nasconde? Qualcosa che gli altri Custodi non sanno,
qualcosa che potrebbe cambiare tutto se venisse scoperto. Un Segreto
potente è un regalo al Custode: è una bomba narrativa che esploderà al
momento perfetto.

Esempi di Personaggio Completo

Quattro Guardiani pronti al gioco - uno per Casata - per mostrarti
come si assemblano le scelte e per darti ispirazione.

:::box[Marco Ferretti - Avalon, Il Paladino]{type=casata_avalon}
**Concept:** Ex-poliziotto che ha visto troppo. L'Anello lo scelse dopo una sparatoria quasi-fatale contro cultisti in un magazzino di Lambrate. Accettò per proteggere altri dagli orrori che aveva scoperto. **Età: 35 \| Quartiere: Porta Venezia \| Vita Normale:** Detective privato (copertura perfetta). **Aspetto:** Cicatrice sul collo, capelli grigi prematuri, porta sempre il distintivo da ex-poliziotto.
:::

:::box[Marco Ferretti - Avalon, Il Paladino (segue)]{type=casata_avalon}
**Caratteristiche:** FOR +1, CUO +1, MEN 0, CAR +2, FAT -1 **PF:** 22 (20 + 2) \| Stress: 0/10 \| Punti Fato: 2 **Poteri L1:** Luce Guida (rivelazione), Scudo Radiante (difesa), Guarigione Minore (cura). **Equipaggiamento:** Anello Avalon, smartphone, auricolare, Glock 19, manganello, 500€, giacca kevlar leggera. **Legami:** Sofia Conti (ex collega detective) - Confidente L1, **Ancora dell'Anello** -
:::

:::box[Marco Ferretti - Avalon, Il Paladino (segue)]{type=casata_avalon}
- guida spirituale, sa dei Custodi.
**Citazione:** «Ho giurato di proteggere. Non importa da cosa.»
**Paura:** Fallire di nuovo. Persone sono morte per colpa sua.
**Desiderio:** Redenzione. Salvare abbastanza vite da bilanciare
quelle perse.
**Segreto:** Uccise un cultista disarmato per vendetta, non per
autodifesa.
:::

:::box[Leila Ferrara - Umbra, L'Infiltratrice]{type=casata_umbra}
**Concept:** Ex-detective della Questura, lasciò per «burnout». In realtà, il burnout era causato dal vedere cose che nessuno voleva credere. L'Anello la trovò durante un'indagine sotto copertura finita in un rituale occulto. **Età: 41 \| Quartiere: Navigli \| Vita Normale:** Consulente di sicurezza freelance.
:::

:::box[Leila Ferrara - Umbra, L'Infiltratrice (segue)]{type=casata_umbra}
**Aspetto:** Capelli neri corti, occhi scuri che non battono mai abbastanza, giacca di pelle consumata, anello d'ombra quasi invisibile al mignolo. **Caratteristiche:** FOR -1, CUO +1, MEN +1, CAR 0, FAT +2 **PF:** 18 (20 - 2) \| Stress: 0/10 \| Corruzione: 0/8 \| Punti Fato: 2 **Poteri L1:** Fondersi nelle Ombre (furtività), Occhi Notturni (percezione), Lama d'Ombra (offensivo). Tutti a costo 0 Corruzione.
:::

:::box[Leila Ferrara - Umbra, L'Infiltratrice (segue)]{type=casata_umbra}
**Equipaggiamento:** Anello Umbra, smartphone, auricolare, coltello a serramanico, grimaldelli, 500€, vestiti scuri. **Legami:** Commissario Rossi (ex capo) - Rivale L1 - lui non le ha mai creduto, lei vuole dimostrargli che aveva ragione. Sara (figlia, 16 anni) - Protettore L1, **Ancora dell'Anello** - la ragione per cui torna sempre a casa. **Citazione:** «La verità è come un'ombra: più la cerchi, più si nasconde.»
:::

:::box[Leila Ferrara - Umbra, L'Infiltratrice (segue)]{type=casata_umbra}
**Paura:** Che la Corruzione la trasformi e Sara la veda per quello che sta diventando. **Desiderio:** Smantellare il culto che quasi la uccise. **Segreto:** Durante l'indagine sotto copertura, uccise un innocente scambiandolo per un cultista. Il caso fu insabbiato.
:::

:::box[Professor Kwame Asante - Ife, Il Druido Urbano]{type=casata_ife}
**Concept:** Docente di Botanica alla Statale di Milano, originario del Ghana. Sentiva le piante parlare da sempre - pensava fosse una metafora. L'Anello gli ha dimostrato che non lo era. **Età: 62 \| Quartiere: Isola \| Vita Normale:** Professore universitario, vive solo con un gatto chiamato Yaw. **Aspetto:** Alto, capelli bianchi, occhiali rotondi, sempre con un rametto verde nella tasca del giacca.
:::

:::box[Professor Kwame Asante - Ife, Il Druido Urbano (segue)]{type=casata_ife}
Le piante nel suo ufficio crescono troppo velocemente. **Caratteristiche:** FOR 0, CUO +1, MEN +1, CAR -1, FAT +2 **PF:** 20 (20 + 0) \| Stress: 0/10 \| Punti Fato: 2 **Poteri L1:** Crescita Rapida (controllo vegetale), Tocco Vitale (guarigione), Sensi Animali (percezione).
:::

:::box[Professor Kwame Asante - Ife, Il Druido Urbano (segue)]{type=casata_ife}
**Equipaggiamento:** Anello Ife, smartphone, auricolare, bastone da passeggio (arma improvvisata), 500€, giacca tweed con tasche piene di semi. **Legami:** La Grande Quercia del Parco Sempione - Mentore L1, **Ancora dell'Anello** - sì, un albero. Ha 400 anni e sa più cose di qualsiasi Custode. Dottoressa Yuki Tanaka (collega, Dipartimento di Biologia) - Confidente L1 - sospetta qualcosa ma non fa domande.
:::

:::box[Professor Kwame Asante - Ife, Il Druido Urbano (segue)]{type=casata_ife}
**Citazione:** «La natura non affretta. E nemmeno io.» **Paura:** Che l'umanità distrugga l'equilibrio naturale prima che lui possa proteggerlo. **Desiderio:** Trovare il modo di far convivere il mondo occulto e il mondo naturale in pace. **Segreto:** Nel 2019, durante un esperimento, creò accidentalmente una pianta senziente. La tiene nel suo ufficio. Lei è cosciente.
:::

:::box[Elena Marchetti - Mictlan, La Medium]{type=casata_mictlan}
**Concept:** Graphic designer di giorno, medium per necessità di notte. Sentiva voci da bambina. I genitori la portarono da psicologi per anni. L'Anello arrivò il giorno in cui una voce le salvò la vita - la avvertì di non prendere quel treno. **Età: 28 \| Quartiere: Porta Ticinese \| Vita Normale:** Graphic designer freelance, lavora da casa con cuffie e musica alta per coprire le voci.
:::

:::box[Elena Marchetti - Mictlan, La Medium (segue)]{type=casata_mictlan}
**Aspetto:** Magra, occhiaie perenni, tatuaggio di catrina sull'avambraccio sinistro, anello di ossidiana al medio. Veste sempre di nero - non per scelta estetica, ma perché i colori la distraggono. **Caratteristiche:** FOR +1, CUO +1, MEN 0, CAR -1, FAT +2 **PF:** 29 (28 + 1) \| Stress: 0/10 \| Punti Fato: 2 **Potere Passivo:** Sangue Tenace. **Poteri L1:** Vedere Oltre il Velo (percezione), Tocco del Gelo (offensivo), Parlare con i Morti (comunicazione).
:::

:::box[Elena Marchetti - Mictlan, La Medium (segue)]{type=casata_mictlan}
**Sangue Tenace:** entro i limiti descritti nel capitolo della Casata, Elena può convertire parte del costo in PF dei poteri in Stress.
:::

:::box[Elena Marchetti - Mictlan, La Medium (segue)]{type=casata_mictlan}
**Equipaggiamento:** Anello Mictlan, smartphone, auricolare, coltello rituale (arma), 500€, vestiti neri, quaderno per annotare le testimonianze degli spiriti. **Legami:** Nonna Lucia (spirito) - Mentore L1, **Ancora dell'Anello** - morta 5 anni fa, rifiuta di andarsene finché Elena «non impara a vivere».
:::

:::box[Elena Marchetti - Mictlan, La Medium (segue)]{type=casata_mictlan}
Marco Ferretti (Avalon) - Protettore L1 - il PG di un altro giocatore; Marco la protegge in combattimento, lei gli parla con i morti che lo tormentano. **Citazione:** «I morti ricordano a modo loro. I vivi scelgono che cosa dimenticare.» **Paura:** Che le voci non siano spiriti ma segnali che sta perdendo la ragione. **Desiderio:** Capire perché l'Anello ha scelto lei - e se lo merita. **Segreto:** Lo spirito di suo padre appare ogni notte.
:::

:::box[Elena Marchetti - Mictlan, La Medium (segue)]{type=casata_mictlan}
Non le ha mai detto come è morto. E lei ha troppa paura di chiedere.
:::

La Session Zero

Prima di giocare la prima sessione vera, dedicate 2--3 ore alla Session
Zero - la sessione di preparazione dove stabilite tono, aspettative e
connessioni di gruppo. La Session Zero non è opzionale: è la sessione
più importante della campagna. Un gruppo che salta la Session Zero
scoprirà i problemi durante il gioco, quando è troppo tardi per
risolverli senza drama.

## 1. Stabilire il Contratto Sociale

Discutete apertamente questi punti. Non ci sono risposte giuste o
sbagliate - c'è solo ciò che funziona per il vostro gruppo:

**Tono.** Quanto dark volete andare? Realistico e crudo, o cinematico ed
eroico? L'umorismo è benvenuto? Mythic Rings può essere giocato come un
thriller horror, come un'avventura urbana, o come un mix dei due.
Decidete insieme.

**Violenza.** Descrizioni grafiche o fade-to-black? Quando il Mictlan
rianimare un cadavere, descrivete il processo in dettaglio o dite
semplicemente «il corpo si alza»? Non c'è una risposta giusta -
dipende dal comfort di tutti al tavolo.

**Temi sensibili.** Cosa è assolutamente off-limits? Trauma, violenza
sessuale, abuso su minori, fobia specifiche - ogni giocatore ha il
diritto di stabilire confini, e ogni confine va rispettato senza
discussione.

**Commitment.** Quanto spesso giocate? Quanto durano le sessioni? Chi
avvisa se non può venire? Stabilire le aspettative logistiche ora evita
frustrazioni dopo.

## 2. Creare i PG Insieme

Non create i personaggi separatamente. Fatelo alla Session Zero, fianco
a fianco, per poter coordinare le scelte: assicurate un mix di Casate,
create Legami tra PG, allineate le backstory (evitate contraddizioni), e
bilanciate i ruoli nel gruppo. Un gruppo dove tutti vogliono fare il
guerriero in prima linea avrà problemi; un gruppo dove nessuno sa curare
avrà problemi peggiori.

## 3. Stabilire le Connessioni di Gruppo

Rispondete insieme a queste domande:

**Come vi conoscete?** Siete stati reclutati insieme? Siete una squadra
esistente che lavora da mesi? Vi siete appena incontrati e dovete ancora
imparare a fidarvi?

**Quanto tempo lavorate insieme?** Giorni, mesi, anni? La risposta
cambia drasticamente le dinamiche di gruppo.

**Fiducia reciproca?** Vi fidate ciecamente o siete ancora cauti? Un
Avalon si fida dell'Umbra? L'Ife accetta i metodi del Mictlan?

**Dinamiche.** Chi è il leader naturale? Chi è lo scettico? Chi tiene
insieme il gruppo con l'umorismo? Chi è il più pericoloso quando perde
il controllo?

## 4. Scenario Iniziale

Il Custode presenta la prima missione - senza spoiler, ma con
abbastanza dettagli per agganciare i giocatori. Contesto (perché
l'Organizzazione vi assegna questa missione), posta in gioco (cosa
succede se fallite), e hook personali (come la missione coinvolge la
backstory di almeno un PG). Un buon hook personale trasforma una
missione generica in una storia personale.

Strumenti di Sicurezza

Mythic Rings può toccare temi dark: morte, violenza, horror, perdita,
corruzione morale. È un gioco che funziona meglio quando va in
profondità - ma «profondità» non significa «disagio». Usate gli
strumenti di sicurezza per garantire che **tutti** si divertano.

:::box[🛑 X-Card]{type=info}
Metti una carta (o un post-it) con una X scritta al centro del tavolo. Chiunque, in qualsiasi momento, può toccare la X-Card. Questo significa: «Mi sento a disagio, cambiamo scena adesso.» Regole: nessuno chiede perché. Nessuno giudica. Il Custode cambia scena immediatamente («Ok, saltiamo avanti\...»). Può essere usata infinite volte. Non servono spiegazioni - né durante, né dopo.
:::

:::box[🛑 X-Card (segue)]{type=info}
Per il gioco online: stabilite una parola chiave in chat (es. «X») o un gesto (pollice in giù in webcam) che funzioni come X-Card digitale.
:::

:::box[Lines & Veils]{type=info}
**Lines** sono i confini assoluti: temi che NON vengono toccati in nessuna circostanza. Non accennati, non implicati, non suggeriti. Se qualcuno mette «violenza su animali» come Line, nel vostro gioco nessun animale verrà mai ferito, punto. **Veils** sono i fade-to-black: temi che possono esistere nella fiction ma vengono gestiti «a sipario calato», senza descrizioni dettagliate.
:::

:::box[Lines & Veils (segue)]{type=info}
Se qualcuno mette «tortura» come Veil, un PNG può essere torturato nella storia, ma la scena si interrompe prima dei dettagli e riprende dopo. Compilate Lines & Veils alla Session Zero. Chiunque può aggiungere temi in qualsiasi momento della campagna.
:::

:::box[Il Debriefing]{type=info}
Alla fine di ogni sessione, il Custode chiede: «C'è qualcosa che vi
ha messo a disagio? Qualcosa che vorreste più o meno di la prossima
volta?» Due minuti di debriefing prevengono settimane di tensione non
detta. Fatelo sempre. Non è opzionale.
Se giocate online, considerate un breve modulo anonimo post-sessione.
:::

:::box[Fine Capitolo 4 - Creare il Tuo Guardiano]{type=tip}
Ora hai tutti gli strumenti per creare il tuo Guardiano: un concept che racconta una storia, una Casata che risuona con la tua visione, caratteristiche bilanciate, Legami che ancorano il personaggio al mondo, e i tocchi finali che lo rendono unico. Hai visto quattro esempi completi e sai come organizzare una Session Zero efficace. **Prossimo capitolo:** Le Regole Base.
:::

:::box[Fine Capitolo 4 - Creare il Tuo Guardiano (segue)]{type=tip}
Come si tira, come funzionano le mosse, cosa succede con un 10+, un 7--9 e un 6--. Il cuore meccanico di Mythic Rings.
:::
