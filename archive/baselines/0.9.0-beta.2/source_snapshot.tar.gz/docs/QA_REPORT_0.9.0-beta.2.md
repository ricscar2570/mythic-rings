# QA Report — Mythic Rings 0.9.0-beta.2

Data audit: **2026-08-10**  
Ambito: **Ring Core — Risonanza dell'Anello e Ancora dell'Anello**

## Stato sintetico

La beta.2 supera i controlli **semantici, strutturali e di portabilità eseguibili senza reinstallare le dipendenze Node**. La promozione a release artefatta resta sospesa finché un runner GitHub pulito non completa `npm run release:check`, rigenera il lock di paginazione e produce i nuovi DOCX/HTML/PDF. I controlli visivi della beta.1 restano una baseline storica e non vengono estesi automaticamente alla beta.2.

## Modifiche di sistema sottoposte ad audit

- MR-RULE-015 — **Risonanza dell'Anello**;
- MR-RULE-016 — **Ancora dell'Anello**;
- prezzi canonici **Corpo, Anima, Legame, Mondo**;
- Condizione dell'Anello e procedura di risoluzione;
- eleggibilità chiusa a **Usare Potere** e **Mosse Esclusive di Casata che richiedono un tiro**;
- timing Fato → controllo del 2 naturale → Risonanza;
- consumo dell'opportunità: dopo la dichiarazione completa di due prezzi validi l'uso 1/scena è speso anche se il giocatore rifiuta;
- se non esistono due prezzi realmente validi la procedura non parte e l'uso resta disponibile;
- confine di scena anti-reset: round, pause brevi, spostamenti tattici e ambienti adiacenti non generano un nuovo uso mentre conflitto e obiettivo restano gli stessi;
- **Mondo** richiede sempre il Velo Tracker: +1 e una traccia soprannaturale concreta;
- Ancora L1+ e sostituzione Anima → Legame una volta per sessione;
- rimozione della collisione tra Ancora e la capacità L3 di Amato, ora **Radicamento**.

## Controlli superati localmente

### Audit contenuti

Comando:

```bash
python3 scripts/audit_content.py
```

Esito verificato:

```text
Audit contenuti superato: 61 poteri, 31 avversari, 33 capitoli.
```

### Portabilità repository

Comando:

```bash
python3 scripts/check_repository_portability.py
```

Esito verificato:

```text
Controllo portabilità repository superato.
```

Il lockfile non contiene URL di registry specifici dell'ambiente; `requirements.txt` dichiara anche `python-docx`.

### Sintassi e struttura

Superati:

- parsing YAML di `book.yml`, `data/canonical_rules.yml` e `data/adversaries.yml`;
- sincronizzazione versione **0.9.0-beta.2** nei 33 capitoli e nei tre prodotti;
- controllo dei box Markdown;
- controllo delle tabelle Markdown;
- `node --check` di `tests/canonical.test.js`, `scripts/validate.js` e `build/engine.js`;
- rigenerazione del bestiario da `data/adversaries.yml`;
- scansione delle principali formule obsolete e delle collisioni terminologiche.

## Regressioni editoriali chiuse

- **Custode** al singolare è riservato al GM; il singolo portatore in-fiction è un **Guardiano/Guardiana**;
- `custode funerario` nel bestiario è stato sostituito alla fonte strutturata con **sentinella funeraria**;
- grafia canonica: **Anello di Custodia / Anelli di Custodia**;
- distanze canoniche: **Contatto, Vicino, Lontano, Remoto**;
- lo style guide è stato riallineato alla beta.2 e ora viene controllato dai test;
- i quattro Anelli originari sono l'origine delle quattro stirpi/Casate, non gli unici quattro Anelli attivi a Milano.

## Controllo matematico Ring Core

`docs/RING_CORE_BALANCE_MODEL.md` conserva la distribuzione 2d6 e uno stress test teorico della Risonanza. Il modello dimostra che l'upgrade 7–9 → 10+ sarebbe troppo invasivo se il prezzo venisse accettato automaticamente; per questo il blind playtest deve misurare rifiuti, categorie offerte/scelte e quota di 7–9 prima/dopo la Risonanza.

Le soglie riportate nel modello sono **trigger interni di revisione**, non benchmark universali.

## Controlli non certificati in questo ambiente

Il container di sviluppo forza npm attraverso un registry/proxy dell'ambiente e non costituisce un test affidabile del `npm ci` pubblico. Per evitare una falsa certificazione, il QA locale **non** dichiara superati:

- installazione Node da checkout realmente esterno;
- `npm run release:check` completo della beta.2;
- rigenerazione/stabilizzazione del nuovo `data/toc-pages.lock.json`;
- preflight dei nuovi artefatti beta.2;
- ispezione visiva dei nuovi PDF beta.2.

## Gate CI obbligatorio

Da checkout pulito:

```bash
npm ci
python3 -m pip install -r requirements.txt
npm run release:check
```

Per la beta, `release:check` rigenera il lock di paginazione e costruisce l'intera distribuzione. Il workflow carica anche `data/toc-pages.lock.json` tra gli artefatti.

Prima di RC/1.0:

1. eseguire un refresh completo;
2. stabilizzare e committare `data/toc-pages.lock.json`;
3. da checkout pulito eseguire `npm run release:locked`;
4. eseguire preflight e ispezione visiva degli artefatti finali.

## Gate di design ancora aperto

Ring Core resta **normativo per la beta ma sperimentale per la 1.0**. Non va congelato senza blind playtest. In particolare occorre validare:

- percentuale di offerte accettate e rifiutate;
- distribuzione delle categorie Corpo/Anima/Legame/Mondo;
- impatto sulla quota di 7–9;
- durata della decisione al tavolo;
- chiarezza delle Condizioni dell'Anello;
- frequenza con cui il Velo torna concretamente in fiction;
- comprensione spontanea della sequenza da parte dei Custodi blind;
- capacità dei giocatori di ricordare l'Anello come tratto distintivo del gioco.

## Verdetto QA

**Sorgenti beta.2: idonei al gate CI e al blind playtest.**  
**Artefatti beta.2: non ancora certificati finché il runner pulito non completa la build e il nuovo controllo visivo.**  
**Ring Core: candidato alla 1.0, non ancora congelato.**
