# Mythic Rings — Canonical Rules Specification

Questa specifica è il secondo livello della fonte normativa del sistema. In caso di divergenza, `data/canonical_rules.yml` prevale; questa specifica traduce gli invarianti che manuale, quick reference, FAQ e prodotti derivati devono rispettare.

## Principi di canonizzazione

1. Una regola completa compare in un solo punto normativo e le sue sintesi devono essere semanticamente equivalenti.
2. Le sintesi non possono introdurre eccezioni.
3. Il Custode non tira dadi per gli avversari.
4. I modificatori non devono cancellare stabilmente la fascia 7–9.
5. L'Anello può cambiare un esito soltanto attraverso **Risonanza** e un prezzo dichiarato, mai come bonus nascosto.
6. Un indizio necessario non è mai negato da un singolo tiro.
7. Le risorse non possono essere recuperate tramite cicli a guadagno netto.
8. Ogni eccezione deve indicare esplicitamente la regola che modifica.

## Regole canoniche

Le regole **MR-RULE-001 — MR-RULE-016** sono definite integralmente in `data/canonical_rules.yml`. Ogni modifica richiede:

- un ADR in `docs/decisions/`;
- aggiornamento dei capitoli normativi e dei prodotti derivati;
- aggiornamento dei test e degli audit;
- incremento di versione quando cambia il comportamento al tavolo.

## Invarianti Ring Core — beta.2

### MR-RULE-015 — Risonanza dell'Anello

- **Eleggibilità:** soltanto **Usare Potere** e le **Mosse Esclusive di Casata che richiedono un tiro**.
- **Momento:** dopo eventuale Fato e prima delle conseguenze del risultato finale.
- **Frequenza:** una volta per scena per Guardiano. Una scena è un'unità continua di luogo, tempo e obiettivo immediato; non si resetta per round, pausa breve, spostamento tattico o ambiente adiacente mentre il conflitto resta lo stesso. Il Custode chiarisce i casi dubbi prima del tiro successivo.
- **Upgrade:** 6− → 7–9 oppure 7–9 → 10+.
- **Eccezioni:** il 2 naturale non migliora; si controlla sui due dadi finali dopo eventuale Fato. Ultimo Respiro, downtime, azioni mondane e poteri senza tiro non sono eleggibili.
- **Prezzo:** il Custode offre due categorie differenti, realmente valide, e dichiara per intero entrambi i prezzi. Se non può formularne due, la procedura non parte e l'uso resta disponibile. Dopo la dichiarazione completa di due prezzi validi, l'uso della scena è speso anche in caso di rifiuto; il giocatore ne accetta uno oppure mantiene il risultato originale.
- **Ordine:** si risolve l'esito migliorato e subito dopo si applica il prezzo, prima di una nuova azione.
- **Nessuna doppia conseguenza:** non si applica anche la conseguenza dell'esito originale migliorato; il costo base del potere già pagato resta invece pagato.

Categorie canoniche:

- **Corpo:** −4 PF ignorando Armatura, non riducibili/convertibili/trasferibili; può attivare Ultimo Respiro dopo l'effetto.
- **Anima:** Condizione dell'Anello nuova o significativamente diversa, con limite concreto e via di risoluzione giocabile.
- **Legame:** conseguenza concreta su un Legame L1+ raggiungibile dalla fiction; nessuna perdita automatica di livello.
- **Mondo:** Velo Tracker +1 e una traccia reale; non è disponibile a Velo 12 salvo procedura di campagna esplicita oltre la Rivelazione.

I due prezzi devono essere **entrambi realmente applicabili** e non possono duplicare un costo obbligatorio già pagato per lo stesso tiro.

### MR-RULE-016 — Ancora dell'Anello

- Alla creazione si designa un **Legame L1+** come Ancora.
- Non concede bonus numerici.
- Una volta per sessione, se l'Ancora è direttamente presente o in contatto significativo e viene offerto **Anima**, il giocatore può chiedere di sostituire quel prezzo con **Legame** sull'Ancora; se l'altro prezzo era già Legame, questa è l'unica eccezione alle categorie differenti e le due conseguenze devono restare materialmente diverse.
- Il Custode dichiara il nuovo prezzo prima della scelta.
- Se l'Ancora scende a L0 o viene spezzata, una nuova Ancora richiede una scena significativa e non può essere scelta nel mezzo della stessa risoluzione.

La beta.2 non presume che questa configurazione sia già bilanciata. I criteri quantitativi e le varianti di fallback sono definiti in `docs/RING_CORE_BALANCE_MODEL.md` e devono essere verificati nel blind playtest prima della 1.0.

## Gerarchia delle fonti

1. `data/canonical_rules.yml`;
2. `docs/CANONICAL_RULES_SPEC.md`;
3. capitolo 5, *Come si gioca*;
4. capitolo 6, *Mosse base*;
5. capitoli delle Casate e dei poteri;
6. quick reference e prodotti derivati;
7. FAQ.

La gerarchia serve per diagnosticare una regressione, non per giustificarla. Una release candidata non deve contenere divergenze tra questi livelli.
