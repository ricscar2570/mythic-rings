# ADR-009 — Risonanza e Ancora dell'Anello

- **Stato:** accettata per beta 0.9.0-beta.2; da validare nel blind playtest
- **Decisione:** 2026-08-10
- **Ambito:** meccanica-identità degli Anelli

## Problema

Il titolo e la fiction attribuiscono agli Anelli un ruolo centrale, ma la beta precedente poteva essere descritta quasi interamente senza chiamarli in causa come procedura distintiva. Aggiungere una nuova risorsa avrebbe aumentato il carico amministrativo.

## Decisione

Introdurre **Risonanza dell'Anello** come nodo delle economie già esistenti.

Una volta per scena, dopo eventuale Fato, un Guardiano può migliorare di una fascia un 6− o 7–9 ottenuto con **Usare Potere** oppure una **Mossa Esclusiva di Casata che richiede un tiro**. Il Custode offre due prezzi di categorie differenti, realmente validi e interamente dichiarati. Se non può formularne due, la procedura non parte e l'uso resta disponibile. Dopo che due prezzi validi sono stati dichiarati, l'opportunità di Risonanza della scena è spesa anche se il giocatore li rifiuta; in quel caso conserva il risultato originale.

Categorie canoniche:

- **Corpo:** −4 PF, ignora Armatura;
- **Anima:** Condizione dell'Anello persistente;
- **Legame:** conseguenza concreta su un Legame esistente;
- **Mondo:** Velo Tracker +1 e una traccia reale.

Il 2 naturale, valutato sui dadi finali dopo eventuale Fato, non è migliorabile; Ultimo Respiro, downtime, azioni mondane e poteri senza tiro sono esclusi. Il costo base già pagato resta pagato.

Una scena è un'unità continua di luogo, tempo e obiettivo immediato: round, pause brevi, spostamenti tattici e ambienti adiacenti non resettano l'uso finché il conflitto resta sostanzialmente lo stesso.

I due prezzi devono essere realmente applicabili e non possono presentare come nuovo prezzo una conseguenza già interamente pagata. Possono colpire la stessa risorsa del costo base soltanto aggiungendo davvero l'effetto canonico del prezzo. **Anima** richiede limite e via di risoluzione; **Legame** richiede un Legame L1+ raggiungibile dalla conseguenza; **Mondo** non può essere offerto a Velo 12 salvo una procedura di campagna esplicita oltre la Rivelazione.

Introdurre inoltre **Ancora dell'Anello**: un Legame L1+ scelto alla creazione. Una volta per sessione, se l'Ancora è presente o in contatto significativo, può trasformare un prezzo Anima offerto in un prezzo Legame sull'Ancora, dichiarato prima della scelta. Se l'altro prezzo era già Legame, i due prezzi possono eccezionalmente condividere la categoria ma devono avere conseguenze diverse.

## Perché

- rende l'Anello meccanicamente inseparabile dall'identità del gioco;
- collega potere, PF, Condizioni, Legami e Velo senza un nuovo tracker;
- crea agency: il giocatore può sempre rifiutare il prezzo;
- è progettata per preservare la fascia 7–9 limitando la Risonanza a una volta per scena e richiedendo un costo reale; questa ipotesi deve essere confermata dal blind playtest;
- rende il Velo un debito collettivo volontariamente assumibile.

## Alternative scartate

1. **Nuova risorsa Risonanza:** scartata per carico amministrativo e rischio di ridondanza con Fato.
2. **Bonus fisso dell'Anello:** scartato perché appiattirebbe ulteriormente la curva 2d6.
3. **Risonanza illimitata:** scartata perché trasformerebbe quasi ogni 7–9 in 10+.
4. **Prezzo scelto liberamente dal giocatore:** scartato perché favorirebbe la categoria sistematicamente meno costosa nel contesto.
5. **Prezzo nascosto deciso dal Custode:** scartato perché riduce agency e leggibilità del rischio.

## Conseguenze e rischi da testare

- possibile aumento eccessivo dei 10+;
- prezzo Mondo scelto troppo spesso nelle one-shot;
- prezzo Corpo dominante per personaggi con molti PF;
- prezzi Anima percepiti come vaghi o punitivi;
- rallentamento del ritmo dovuto alla negoziazione;
- Ancora dimenticata o usata come semplice assicurazione meccanica.

## Criterio di permanenza nella 1.0

La regola resta soltanto se gruppi ciechi la comprendono senza intervento dell'autore, se nessuna categoria domina stabilmente, se esistono sia accettazioni sia rifiuti significativi e se la fascia 7–9 conserva un ruolo centrale. Le soglie operative sono in `docs/RING_CORE_BALANCE_MODEL.md`.
