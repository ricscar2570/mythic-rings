# Gate di pubblicazione

## Gate A - Integrita editoriale

- [ ] Nessun placeholder.
- [ ] Nessuna nota di versione nel corpo del manuale.
- [ ] Glossario, FAQ e quick reference coerenti con la specifica canonica.
- [ ] Esempi numerici verificati.
- [ ] Crediti completi e autorizzati.

## Gate B - Sistema

- [ ] Tutte le regole MR-RULE hanno test automatici o controlli di consistenza.
- [ ] Bestiario valido e player-facing.
- [ ] Poteri revisionati per costi, durata, portata e azioni.
- [ ] Blind playtest superato.
- [ ] Risonanza dell'Anello validata nel blind playtest secondo `docs/RING_CORE_BALANCE_MODEL.md`: procedura compresa, prezzi non dominanti, 7–9 ancora rilevante, Ancora utilizzabile senza ambiguità.

## Gate C - Produzione

- [ ] `npm ci && npm run release:check` passa sul runner GitHub per la beta, rigenerando la paginazione quando necessario.
- [ ] Prima di RC/1.0, `data/toc-pages.lock.json` è stato rigenerato e committato e `npm run release:locked` passa da checkout pulito senza modificarlo.
- [x] DOCX, HTML e PDF contengono gli stessi capitoli entro il controllo di parità previsto dal preflight.
- [x] PDF preflight senza errori bloccanti.
- [x] Indice e segnalibri funzionano.
- [x] Metadati e versione corretti.

## Gate D - Legale e commerciale

- [ ] Titolarita di testi, font e materiali verificata.
- [ ] Nome e marchio verificati.
- [ ] Dicitura PbtA verificata.
- [ ] ISBN reale o assente.
- [ ] Fiscalita, IVA, termini e rimborsi verificati.
- [ ] Quickstart e pagina di supporto disponibili.
