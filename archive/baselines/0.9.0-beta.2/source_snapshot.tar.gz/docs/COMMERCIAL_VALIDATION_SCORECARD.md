# Scorecard di validazione commerciale

Questa scheda impedisce di confondere interesse generico con domanda verificata.

## Funnel quickstart

| Metrica | Valore | Soglia interna | Esito | Fonte |
|---|---:|---:|---|---|
| Visite pagina |  | da definire prima del test |  | analytics |
| Download quickstart |  |  |  | piattaforma |
| Conversione visita → download |  |  |  | calcolo |
| Iscrizioni newsletter |  |  |  | provider |
| Conversione download → iscrizione |  |  |  | calcolo |
| Sessioni dichiarate |  |  |  | modulo |
| Moduli completi |  |  |  | modulo |
| Interesse all'acquisto |  |  |  | questionario |
| Prezzo percepito mediano |  |  |  | questionario |

## Qualità del pubblico

| Indicatore | Valore | Decisione |
|---|---:|---|
| Custodi disposti a condurre ancora |  |  |
| Gruppi che completano lo scenario |  |  |
| Utenti attivi dopo 30 giorni |  |  |
| Recensioni o resoconti spontanei |  |  |
| Creator disponibili a provarlo |  |  |

## Economia

- Costi fissi non grafici:
- Costo unitario stimato:
- Prezzo lordo ipotizzato:
- Ricavo netto medio:
- Copie di break-even:
- Pubblico qualificato necessario nello scenario prudente:
- Riserva imprevisti:

## Gate

La decisione di vendita o crowdfunding deve indicare:

- dati usati;
- ipotesi;
- scenario prudente;
- principale rischio;
- condizione che annulla o rinvia il lancio;
- responsabile della decisione.


## Comprensione della meccanica-identità

Dopo il quickstart, chiedere senza suggerimenti:

- «Qual è la regola che rende Mythic Rings diverso dagli altri urban fantasy?»
- «Che cosa succede quando i dadi non ti danno abbastanza?»
- «Che cosa può chiederti l'Anello in cambio?»

Segnale qualitativo forte: i partecipanti citano spontaneamente **Risonanza / prezzo dell'Anello** e sanno descriverne almeno due categorie di costo. Se il titolo *Mythic Rings* viene ricordato ma la funzione degli Anelli no, la promessa non è ancora abbastanza centrale e va rivista prima della 1.0.
