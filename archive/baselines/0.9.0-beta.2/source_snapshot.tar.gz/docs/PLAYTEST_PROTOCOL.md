# Protocollo di playtest

## Obiettivo

Verificare che il gioco funzioni senza la presenza dell'autore, che le procedure siano comprensibili e che nessuna Casata o combinazione domini stabilmente le altre.

## Ondate

### Alpha diagnostica

- 8-12 sessioni guidate.
- Test mirati su Punti Fato, Legami, Riprendersi, Ultimo Respiro, Armatura, Escalation e indagine.
- Un cambiamento per volta quando possibile.

### Beta chiusa

- minimo 10 gruppi;
- minimo 30 sessioni complessive;
- almeno 3 gruppi con Custode non coinvolto nello sviluppo;
- raccolta di log, tempi e questionari.

### Blind playtest

- minimo 5 Custodi esterni;
- nessun chiarimento sincrono durante preparazione e sessione;
- avventura identica per rendere confrontabili i risultati.

## Metriche obbligatorie

- tempo di creazione del personaggio;
- tempo di preparazione del Custode;
- durata degli scontri;
- frequenza 10+, 7-9 e 6-;
- regole consultate piu di due volte;
- regole interpretate in modi differenti;
- scelta dei poteri e delle Casate;
- uso e conservazione dei Punti Fato;
- casi in cui l'indagine si blocca;
- soddisfazione e desiderio di una seconda sessione.

## Test specifico della Risonanza dell'Anello

Per ogni sessione registra:

- tiri eleggibili alla Risonanza;
- Risonanze invocate;
- Risonanze accettate e rifiutate;
- esito originale e migliorato;
- due categorie offerte;
- categoria scelta;
- tempo approssimativo della decisione;
- se uno dei due prezzi è sembrato chiaramente irrilevante o dominante;
- uso dell'Ancora;
- conseguenza effettivamente tornata in fiction entro la fine della sessione.

### Gate specifici

La Risonanza resta nella 1.0 soltanto se il blind playtest mostra contemporaneamente:

- comprensione della procedura senza spiegazione dell'autore;
- nessuna confusione ricorrente sull'ordine Fato → Risonanza → prezzo;
- nessuna categoria di prezzo scelta quasi automaticamente in tutti i contesti;
- presenza significativa sia di accettazioni sia di rifiuti;
- nessun aumento sistematico dei 10+ tale da cancellare la fascia 7–9;
- prezzi percepiti come decisioni fictionali, non come tassazione arbitraria;
- incremento medio contenuto del tempo di risoluzione.

Non fissare una percentuale di successo commerciale come prova del design: usa questi dati per individuare dominanze, ambiguità e carico decisionale.

### Red flag quantitativi della beta.2

Queste soglie fanno scattare una revisione, non dimostrano da sole che la regola sia errata. Usarle soltanto con i campioni minimi indicati e consultare `docs/RING_CORE_BALANCE_MODEL.md` per il modello completo.

- almeno 30 offerte: accettazione >75% o rifiuto <15%;
- almeno 20 offerte di una categoria: oltre 55% delle scelte sulla stessa categoria senza spiegazione di scenario;
- almeno 50 tiri eleggibili: 7–9 post-Risonanza <20% oppure calo >15 punti percentuali rispetto allo stesso campione pre-Risonanza;
- dopo la prima sessione: mediana della decisione >45 secondi;
- meno dell'80% dei Custodi blind ricostruisce correttamente la sequenza completa senza aiuto;
- oltre il 10% delle offerte contiene un prezzo fittizio, non applicabile o già pagato.

## Gate beta -> release candidate

- nessun difetto S0, S1 o S2 aperto;
- almeno 80% dei gruppi completa l'avventura senza assistenza;
- almeno 80% dei Custodi dichiara di poter condurre una seconda sessione;
- nessuna procedura centrale interpretata in piu di un modo ricorrente;
- nessun loop di risorse o strategia dominante confermata;
- tutte le quattro Casate giocate in almeno tre tavoli.
