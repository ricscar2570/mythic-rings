# Ring Core — modello di bilanciamento beta.2

## Scopo

Questo documento definisce **ipotesi di test**, non benchmark universali. La Risonanza dell'Anello modifica direttamente la distribuzione degli esiti 2d6 e deve quindi essere validata con dati di tavolo prima della 1.0.

La variabile più sensibile è l'upgrade **7–9 → 10+**. Se i prezzi vengono accettati quasi automaticamente, la Risonanza può ridurre troppo la fascia 7–9, che è una delle principali fonti di decisioni e conseguenze del sistema.

## Distribuzione base del 2d6

Il **2 naturale** resta sempre 6−. Con questa regola la distribuzione è:

| Modificatore | 6− | 7–9 | 10+ |
|---:|---:|---:|---:|
| −1 | 58,3% | 33,3% | 8,3% |
| +0 | 41,7% | 41,7% | 16,7% |
| +1 | 27,8% | 44,4% | 27,8% |
| +2 | 16,7% | 41,7% | 41,7% |
| +3 | 8,3% | 33,3% | 58,3% |
| +4 | 2,8% | 25,0% | 72,2% |

Questa tabella è la baseline. Fato, posizione, poteri e altre fonti possono alterare i risultati osservati al tavolo e devono essere registrati separatamente.

## Stress test teorico della Risonanza

Scenario volutamente estremo: Guardiano con modificatore **+2**, nessun Fato, più tiri eleggibili nella stessa scena, Risonanza usata sulla **prima occasione 6− o 7–9** e prezzo accettato sempre.

| Tiri eleggibili nella scena | 6− osservati per tiro | 7–9 osservati per tiro | 10+ osservati per tiro |
|---:|---:|---:|---:|
| 1 | 0,0% | 16,7% | 83,3% |
| 2 | 4,9% | 24,0% | 71,2% |
| 3 | 7,8% | 28,4% | 63,8% |
| 4 | 9,7% | 31,3% | 59,0% |
| 5 | 11,0% | 33,2% | 55,8% |

La tabella **non prevede il comportamento reale**: dimostra perché il prezzo e la possibilità di rifiutare sono indispensabili. Se il tavolo tratta Risonanza come un upgrade gratuito, il sistema produce troppi esiti pieni, soprattutto nelle scene con pochi tiri eleggibili.

## Metriche obbligatorie

Per ogni offerta di Risonanza registrare:

- Casata e modificatore del tiro;
- tipo di tiro: Usare Potere o Mossa Esclusiva di Casata;
- risultato prima di Fato;
- eventuale Fato e risultato dopo Fato;
- risultato eleggibile 6− o 7–9;
- due categorie di prezzo offerte;
- testo concreto dei due prezzi;
- prezzo accettato oppure rifiuto;
- se la procedura non è partita perché non esistevano due prezzi validi (non conta come uso);
- se i due prezzi validi sono stati dichiarati: l'opportunità della scena è consumata anche in caso di rifiuto;
- risultato finale;
- tempo della decisione;
- conseguenza effettiva del prezzo;
- se la conseguenza è tornata in fiction entro la fine della sessione;
- eventuale uso dell'Ancora.

## Red flag di beta

Le soglie seguenti sono **trigger di revisione**, non criteri statistici universali. Applicarle solo con campioni sufficienti e leggerle insieme ai resoconti qualitativi.

1. **Prezzi troppo economici:** dopo almeno 30 offerte, più del 75% delle Risonanze viene accettato oppure meno del 15% viene rifiutato.
2. **Categoria dominante:** una categoria costituisce più del 55% dei prezzi scelti quando è stata offerta almeno 20 volte e non c'è una chiara spiegazione dovuta agli scenari testati.
3. **Appiattimento del 7–9:** dopo almeno 50 tiri eleggibili, la quota di 7–9 *dopo* la Risonanza scende sotto il 20% oppure cala di oltre 15 punti percentuali rispetto alla quota pre-Risonanza dello stesso campione.
4. **Procedura lenta:** dopo la prima sessione di apprendimento, la mediana della scelta di Risonanza supera 45 secondi.
5. **Procedura non autonoma:** meno dell'80% dei Custodi blind sa ricostruire senza aiuto l'ordine **Fato → eleggibilità → due prezzi dichiarati → scelta → esito migliorato → prezzo**.
6. **Prezzo fittizio:** più del 10% delle offerte contiene una categoria che il gruppo giudica non realmente applicabile, già pagata o priva di conseguenza concreta.
7. **Anima ingestibile:** più del 20% delle Condizioni dell'Anello richiede un chiarimento successivo su che cosa limiti o su come possa essere risolta.
8. **Mondo automatico:** Mondo viene scelto sistematicamente perché l'aumento del Velo non produce conseguenze visibili entro una o due sessioni.

## Varianti di fallback da testare soltanto se necessarie

Non introdurre queste varianti contemporaneamente alla beta.2. Servono come ipotesi controllate se i dati mostrano che l'upgrade 7–9 → 10+ è troppo forte.

### Variante A — Risonanza conservativa

- 6− → 7–9 come ora;
- su 7–9 il Guardiano **non** ottiene 10+: accetta invece un prezzo di Risonanza per rimuovere o sostituire una delle complicazioni previste dal 7–9.

### Variante B — Solo salvataggio

- Risonanza funziona soltanto su 6− → 7–9.

### Variante C — Prezzo crescente

- mantenere entrambi gli upgrade;
- rendere 7–9 → 10+ disponibile soltanto con prezzi di intensità superiore e criteri formalizzati.

La variante da adottare, se necessaria, deve essere scelta con un ADR e un test A/B controllato. Non modificare la 1.0 sulla base di impressioni isolate.

## Criterio per la promozione in 1.0

Risonanza e Ancora possono essere congelate per la 1.0 soltanto quando:

- la procedura è compresa nei blind playtest;
- accettare o rifiutare è una scelta reale;
- nessuna categoria di prezzo è una scorciatoia dominante;
- il 7–9 conserva un ruolo sostanziale;
- le Condizioni dell'Anello sono giocabili e reversibili tramite fiction significativa;
- il Velo rende il prezzo Mondo percepibile;
- la meccanica viene ricordata spontaneamente come tratto distintivo di *Mythic Rings*.
