'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { loadMeta } = require('../build/project-meta');

const root = path.resolve(__dirname, '..');
const meta = loadMeta(root);
const data = yaml.load(fs.readFileSync(path.join(root, 'data/canonical_rules.yml'), 'utf8'));
assert.strictEqual(String(data.product_version), String(meta.version));
assert.strictEqual(data.rules.fate_points.start, 2);
assert.strictEqual(data.rules.fate_points.maximum, 2);
assert.match(data.rules.fate_points.spend, /un solo d6/i);
assert.match(data.rules.last_breath.trigger, /senza Caratteristica o bonus/i);
assert.strictEqual(data.rules.damage_armor.limits.equipment_armor, 3);
assert.strictEqual(data.rules.damage_armor.limits.ordinary_total_armor, 4);
assert.strictEqual(data.rules.damage_armor.limits.boss_armor, 2);
assert.match(data.rules.escalation.text, /senza alterare la curva 2d6/i);
assert.match(data.rules.gm_rolls.text, /non tira/i);
assert.match(data.rules.investigation.guarantee, /ottieni sempre/i);

// Ring Core: the signature mechanic must stay explicit and mechanically bounded.
assert.ok(data.rules.ring_resonance, 'MR-RULE-015 assente');
assert.strictEqual(data.rules.ring_resonance.id, 'MR-RULE-015');
assert.match(data.rules.ring_resonance.frequency, /una volta per scena/i);
assert.match(data.rules.ring_resonance.scene_boundary, /nuovo round/i);
assert.match(data.rules.ring_resonance.scene_boundary, /non si resetta/i);
assert.match(data.rules.ring_resonance.effect, /6- diventa 7-9/i);
assert.match(data.rules.ring_resonance.effect, /7-9 diventa 10\+/i);
assert.match(data.rules.ring_resonance.effect, /2 naturale non può/i);
assert.deepStrictEqual(Object.keys(data.rules.ring_resonance.prices).sort(), ['body', 'bond', 'soul', 'world']);
assert.match(data.rules.ring_resonance.prices.body, /4 PF/i);
assert.match(data.rules.ring_resonance.prices.body, /ignorando.*Armatura/i);
assert.match(data.rules.ring_resonance.prices.world, /Velo Tracker avanza di 1/i);
assert.doesNotMatch(data.rules.ring_resonance.prices.world, /se il tavolo non usa/i);
assert.match(data.rules.ring_resonance.price_procedure, /due prezzi/i);
assert.match(data.rules.ring_resonance.price_procedure, /categorie diverse/i);
assert.match(data.rules.ring_resonance.price_procedure, /rinuncia/i);
assert.match(data.rules.ring_resonance.price_procedure, /non parte/i);
assert.match(data.rules.ring_resonance.price_procedure, /spesa anche se/i);
assert.match(data.rules.ring_resonance.trigger, /Usare Potere/i);
assert.match(data.rules.ring_resonance.trigger, /Mossa Esclusiva di Casata/i);
assert.match(data.rules.ring_resonance.eligibility, /soltanto Usare Potere/i);
assert.match(data.rules.ring_resonance.price_validity.general, /realmente applicabili/i);
assert.match(data.rules.ring_resonance.price_validity.soul, /Condizione nuova/i);
assert.match(data.rules.ring_resonance.price_validity.bond, /Legame L1\+/i);
assert.match(data.rules.ring_resonance.price_validity.world, /Velo 12/i);
assert.match(data.rules.ring_resonance.natural_two_timing, /dadi finali/i);
assert.match(data.rules.ring_resonance.natural_two_timing, /dopo eventuali ritiri di Fato/i);
assert.match(data.rules.ring_resonance.price_validity.general, /stessa risorsa/i);
assert.match(data.rules.ring_anchor.grounding, /eccezione.*categorie differenti/i);
assert.ok(data.rules.ring_anchor, 'MR-RULE-016 assente');
assert.strictEqual(data.rules.ring_anchor.id, 'MR-RULE-016');
assert.match(data.rules.ring_anchor.creation, /Legami di Livello 1 o superiore/i);
assert.match(data.rules.ring_anchor.grounding, /una volta per sessione/i);
assert.match(data.rules.ring_anchor.grounding, /Anima/i);
assert.match(data.rules.ring_anchor.grounding, /Legame/i);

const mustMirrorRingCore = [
  'chapters/05_come_si_gioca.md',
  'chapters/30_quick_reference_giocatori.md',
  'chapters/31_quick_reference_custode.md',
  'products/quickstart/Mythic_Rings_Quickstart.md',
  'products/player-kit/Mythic_Rings_Kit_del_Giocatore.md',
];
for (const rel of mustMirrorRingCore) {
  const text = fs.readFileSync(path.join(root, rel), 'utf8');
  assert.match(text, /Risonanza dell'Anello/i, `${rel}: Risonanza assente`);
  assert.match(text, /6−\s*(?:→|diventa)\s*7[–-]9/i, `${rel}: upgrade 6− non esplicito`);
  assert.match(text, /7[–-]9\s*(?:→|diventa)\s*10\+/i, `${rel}: upgrade 7–9 non esplicito`);
  assert.match(text, /Corpo/i, `${rel}: prezzo Corpo assente`);
  assert.match(text, /Anima/i, `${rel}: prezzo Anima assente`);
  assert.match(text, /Legame/i, `${rel}: prezzo Legame assente`);
  assert.match(text, /Mondo/i, `${rel}: prezzo Mondo assente`);
  assert.match(text, /Mossa Esclusiva di Casata/i, `${rel}: eleggibilità Risonanza non chiusa`);
  assert.match(text, /(?:spes[ao]|speso).*anche se|anche se.*(?:rifiut|rinunc)/i, `${rel}: rifiuto Risonanza senza consumo opportunità`);
}

const sessionZero = fs.readFileSync(path.join(root, 'chapters/15_session_zero.md'), 'utf8');
assert.doesNotMatch(sessionZero, /Punto Fato extra/i, 'Sessione Zero: Fato oltre il massimo canonico');
assert.doesNotMatch(sessionZero, /\+1 forward al primo tiro/i, 'Sessione Zero: bonus ad hoc per gruppi piccoli');

const quickstart = fs.readFileSync(path.join(root, 'products/quickstart/Mythic_Rings_Quickstart.md'), 'utf8');
const playerKit = fs.readFileSync(path.join(root, 'products/player-kit/Mythic_Rings_Kit_del_Giocatore.md'), 'utf8');
for (const [name, text] of [['quickstart', quickstart], ['player kit', playerKit]]) {
  assert.match(text, /Contatto/i, `${name}: distanza Contatto assente`);
  assert.match(text, /Vicino/i, `${name}: distanza Vicino assente`);
  assert.match(text, /Lontano/i, `${name}: distanza Lontano assente`);
  assert.match(text, /Remoto/i, `${name}: distanza Remoto assente`);
}
assert.doesNotMatch(quickstart, /\|\s*\*\*Medio\*\*\s*\|/i, 'Quickstart: distanza Medio obsoleta');
assert.doesNotMatch(playerKit, /\*\*Medio\*\*\s*·/i, 'Kit: distanza Medio obsoleta');

const ringsChapter = fs.readFileSync(path.join(root, 'chapters/02_i_custodi_e_gli_anelli_di_custodia.md'), 'utf8');
assert.doesNotMatch(ringsChapter, /efficacia ridotta/i, 'Anello: penalità vaga per separazione fisica');
assert.match(ringsChapter, /non applica penalità numeriche implicite/i, 'Anello: separazione fisica non normata');

const oneShots = fs.readFileSync(path.join(root, 'chapters/28_tre_one_shot.md'), 'utf8');
assert.doesNotMatch(oneShots, /Ada Brambilla, custode notturna/i, 'Collisione Custode/ruolo professionale');

const styleGuide = fs.readFileSync(path.join(root, 'docs/EDITORIAL_STYLE_GUIDE.md'), 'utf8');
assert.match(styleGuide, /Custode[^\n]*esclusivamente[^\n]*(?:GM|conduce il gioco)/i, 'Style guide: Custode non riservato al GM');
assert.match(styleGuide, /Contatto, Vicino, Lontano, Remoto/i, 'Style guide: distanze canoniche non allineate');
assert.doesNotMatch(styleGuide, /Distanze:\s*Vicino,\s*Medio,\s*Lontano,\s*Oltre/i, 'Style guide: vecchie distanze ancora normative');
assert.match(styleGuide, /Anello di Custodia \/ Anelli di Custodia/i, 'Style guide: grafia Anello di Custodia non fissata');

const bestiary = fs.readFileSync(path.join(root, 'chapters/26_il_bestiario_di_milano.md'), 'utf8');
assert.doesNotMatch(bestiary, /custode funerario/i, 'Bestiario: Custode usato come personaggio in-fiction');

const downtime = fs.readFileSync(path.join(root, 'chapters/23_le_12_attivita_di_downtime.md'), 'utf8');
assert.match(downtime, /Affrontare una Condizione dell'Anello durante il downtime/i, 'Downtime: procedura Condizione Anello assente');
assert.match(downtime, /beneficio numerico principale/i, 'Downtime: costo opportunità per Condizione Anello assente');

console.log('Test canonici superati.');
