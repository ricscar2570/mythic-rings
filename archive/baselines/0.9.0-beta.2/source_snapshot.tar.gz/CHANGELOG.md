# Changelog

## 0.9.0-beta.2 — Ring Core

- introdotta **Risonanza dell'Anello** (MR-RULE-015), meccanica-identità 1/scena che migliora 6−→7–9 o 7–9→10+ pagando un prezzo dichiarato;
- introdotte le quattro categorie di prezzo **Corpo, Anima, Legame, Mondo** senza aggiungere nuovi tracker;
- introdotta **Ancora dell'Anello** (MR-RULE-016), collegata a un Legame L1+ e utilizzabile una volta per sessione;
- rinominata la capacità L3 del Legame Amato da Ancora a **Radicamento** per eliminare collisioni terminologiche;
- aggiunte procedure per Custode, FAQ, quick reference, quickstart, kit e avventura di playtest;
- aggiunte metriche dedicate per misurare dominanza dei prezzi, frequenza d'uso, rifiuti e impatto sulla fascia 7–9;
- chiarita la lore: le quattro sono **stirpi di Anelli**, non quattro soli artefatti; a Milano sono attivi circa quaranta Anelli, in rapporto ai Guardiani operativi;
- resa la versione dei prodotti derivata dal manifest invece che hardcoded nei principali script di build.
- definita in modo chiuso l'eleggibilità della Risonanza: solo **Usare Potere** e **Mosse Esclusive di Casata con tiro**;
- formalizzata la validità dei quattro prezzi, incluso il limite di Mondo a Velo 12 e il divieto di prezzi fittizi o già pagati;
- aggiunto il modello matematico e le red flag di playtest in `docs/RING_CORE_BALANCE_MODEL.md`;
- riallineate le fasce di distanza di quickstart e kit e rimossi bonus ad hoc per gruppi piccoli incompatibili con i limiti canonici;
- chiarita la separazione fisica dall'Anello e aggiunti esempi completi di Condizione con limite e via di risoluzione.
- chiuso il confine di scena della Risonanza: round, pause brevi e spostamenti tattici non resettano l'uso;
- normato il rifiuto dei prezzi: dopo due prezzi validi dichiarati l'opportunità 1/scena è spesa; se non esistono due prezzi validi la procedura non parte;
- reso **Mondo** dipendente sempre dal Velo Tracker, eliminando il fallback senza tracker;
- riallineata la style guide editoriale e protette terminologia, distanze e ruolo del Custode con test di regressione;
- aggiunto `docs/QA_REPORT_0.9.0-beta.2.md` con stato verificato e gate ancora aperti.

## Correzione pipeline CI della 0.9.0-beta.1

- reso `release:check` autosufficiente su checkout puliti: ricostruisce `dist/` prima del preflight;
- introdotto `release:preflight` per il controllo rapido degli artefatti già costruiti;
- mantenuto `release:build` come alias esplicito del gate completo;
- riallineati workflow CI, README e guida alla contribuzione alla nuova semantica dei comandi.
- resa deterministica la conversione LibreOffice dei prodotti: un PDF completo e stabile viene validato e il processo headless eventualmente rimasto sospeso viene terminato in modo controllato.
- aggiornato il lockfile npm: `npm audit` non segnala vulnerabilità note nella dipendenza risolta.
- verificato `npm run release:check` da `dist/` assente: exit code 0, 13 artefatti validi.

## 0.9.0-beta.1

- introdotta una fonte canonica delle regole;
- unificati Punti Fato, Legami, Riprendersi e Ultimo Respiro;
- normalizzati danno, Armatura e combattimento player-facing;
- Escalation spostata dal tiro al danno;
- Investigare riscritto in forma fail-forward;
- rimossi riferimenti interni alle patch dal manuale;
- aggiunti manifest, gate di release, style guide e protocollo di playtest;
- aggiornata la pipeline per produrre artefatti con metadati unici;
- rimossi placeholder noti da colophon e crediti.
- sviluppata la campagna *Il Crepuscolo del Velo* con procedure di conduzione, stato persistente e finali reattivi;
- ampliato il quickstart con Condizioni, equipaggiamento, esempio di tiro, preparazione del Custode e checklist blind;
- ricostruito il Kit del Giocatore con scheda, tracker, mosse, Legami, avanzamento e sicurezza;
- aggiunta *Notte al Monumentale* come avventura autonoma con handout e rapporto di playtest;
- aggiornati audit e preflight per includere tutti i prodotti di ingresso;
- riscritto il README per riflettere la pipeline e la struttura effettive;
- completata l'ispezione visiva integrale di manuale, quickstart, kit e avventura;
- reso atomico e incrementale il post-processing PDF, con verifica prima della sostituzione;
- isolate le conversioni LibreOffice con profili temporanei, timeout e terminazione controllata;
- ridotti i segnalibri dei prodotti ai soli livelli editorialmente utili;
- superato il preflight tecnico dei quattro PDF;
- documentato l'audit DOCX e il limite noto relativo alle tabelle di impaginazione;
- aggiunto il rapporto di qualità `docs/QA_REPORT_0.9.0-beta.1.md`;
- introdotto un lock di paginazione verificato, con build PDF ordinaria a un passaggio e comando separato di rigenerazione;
- separati il controllo rapido `release:preflight` e il gate autosufficiente `release:check`/`release:build`, che ricostruisce l’intera distribuzione.

## Archivio 3.2

Il changelog storico della revisione 3.2 è conservato in `archive/CHANGELOG_v3.2_fix.md`.
